create
    definer = root@localhost procedure p1()
begin
		declare sId VARCHAR(20);
    declare price float;
    declare sale int;
    -- 声明游标
    declare mc cursor for select sightId,qunarPrice,saleCount from t_temp;
    -- 打开游标
    open mc;
		loop  -- 循环，将表的内容都转移到class2中
    -- 获取结果
    fetch mc into sId,price,sale;
    -- 这里是为了显示获取结果
		UPDATE t_sightupdateinfo set qunarPrice=price,saleCount=sale WHERE sightId=sId;
		end loop;
    -- 关闭游标
    close mc;
end;

